package com.example.mohamed.musicalstructure;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;

public class SongDetailScreen extends AppCompatActivity {

    TextView textView;
    String[] names1 = {"Song 1", "Song 2"};
    String[] names2 = {"Song 3", "Song 4"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_now_playing);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        textView = (TextView) findViewById(R.id.textView_now_name);
        Intent intent = getIntent();
        int position = intent.getExtras().getInt("position");
        int oneOrTwo = intent.getExtras().getInt("oneOrTwo");
        if (oneOrTwo == 0) {
            textView.setText("PLAYING NOW \n" + names1[position]);
        } else {
            textView.setText("PLAYING NOW \n" + names2[position]);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
