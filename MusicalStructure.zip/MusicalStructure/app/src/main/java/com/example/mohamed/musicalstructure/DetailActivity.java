package com.example.mohamed.musicalstructure;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
    TextView desc;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        desc = (TextView) findViewById(R.id.textView_desc);
        listView = (ListView) findViewById(R.id.listView_detail);
        final Intent intent = getIntent();
        int position = intent.getExtras().getInt("position");
        switch (position) {
            case 0:
                desc.setText(getResources().getString(R.string.display_playlist));
                ArrayAdapter adapter = ArrayAdapter.createFromResource(this, R.array.playlists_arr, android.R.layout.simple_list_item_1);
                listView.setAdapter(adapter);
                break;
            case 1:

                desc.setText(getResources().getString(R.string.display_artists));
                ArrayAdapter adapter2 = ArrayAdapter.createFromResource(this, R.array.artists_arr, android.R.layout.simple_list_item_1);
                listView.setAdapter(adapter2);
                break;
            case 2:
                desc.setText(getResources().getString(R.string.display_albums));
                ArrayAdapter adapter3 = ArrayAdapter.createFromResource(this, R.array.albums_arr, android.R.layout.simple_list_item_1);
                listView.setAdapter(adapter3);
                break;
        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent1 = new Intent(DetailActivity.this, SongsDisplay.class);
                intent1.putExtra("position", position);
                startActivity(intent1);
            }
        });
    }
}
