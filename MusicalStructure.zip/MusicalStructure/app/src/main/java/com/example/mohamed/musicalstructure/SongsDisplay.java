package com.example.mohamed.musicalstructure;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class SongsDisplay extends AppCompatActivity {
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_songs_display);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        listView = (ListView) findViewById(R.id.listView_songs);
        Intent intent = getIntent();
        int position = intent.getExtras().getInt("position");
        final int oneOrTwo = position;
        switch (position) {
            case 0:
                ArrayAdapter adapter = ArrayAdapter.createFromResource(this, R.array.list1_songs, android.R.layout.simple_list_item_1);
                listView.setAdapter(adapter);
                break;
            case 1:
                ArrayAdapter adapter2 = ArrayAdapter.createFromResource(this, R.array.list2_songs, android.R.layout.simple_list_item_1);
                listView.setAdapter(adapter2);
                break;
        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent1 = new Intent(SongsDisplay.this, SongDetailScreen.class);
                intent1.putExtra("position", position);
                intent1.putExtra("oneOrTwo", oneOrTwo);
                startActivity(intent1);
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
